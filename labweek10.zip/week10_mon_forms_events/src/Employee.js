import React from "react";
class Employee extends React.Component{
    constructor(props){
        super(props)

        this.state ={
            txtFirstName : "",
            txtLastName: "",
            txtSalary: ""
        }
    }
    options = ["Alberta", "British Columbia", "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Ontario", "Prince Edward Island", "Quebec", "Saskatchewan"]


    onSubmitData = (event) => {
        event.preventDefault()
        console.log(this.state)
    }

    onValueChange = event => {

        this.setState({
            [event.target.name]:  event.target.value
        })

    }

    render(){
        return(
        <div>
            <h1>Data Entry Form</h1>
            <form onSubmit={e => this.onSubmitData(e)}>
        
                <input onChange={e => this.onValueChange(e)} type="text" name="txtEmail" placeholder="Enter email" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtName" placeholder="Full name" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtAddress" placeholder="1234 Main st" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtAddress2" placeholder="Apartment, studio, or floor" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtCity" placeholder="City" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtSalary" placeholder="Enter Salary" />
                <input onChange={e => this.onValueChange(e)} type="text" name="txtFirstName" placeholder="Postal code" />
                <div style={{float:'left', marginLeft:'10px'}}>
                            <label style={{display: 'flex',  justifyContent:'center', alignItems:'center'}}>Province</label>
                            <select style={{width:'490px', marginTop:'10px'}} name="selectedOption" onChange={e => this.onValueChange(e)}>
                                <option name="selectedOption" key="">Choose...</option>{
                                    this.options.map(selectedOption => {
                                    return (<option key={selectedOption}>{selectedOption}</option>)
                                    })
                                }
                            </select>
                        </div>

                <input type="submit" value="Submit"/>
            </form>
            <h2>Data Output</h2>
                <h5>FullName:{this.state.txtFirstName}</h5>
                <h5>Email:{this.state.txtEmail}</h5>
                <h5>Address: {this.state.txtAddress + this.state.txtAddress2}</h5>
                <h5>City: {this.state.txtCity}</h5>
                <h5>Province: {this.state.selectedOption}</h5>
                <h5>Postal Code: {this.state.txtPostalCode}</h5>
                <hr></hr>
        </div>
        )
    }
}

export default Employee