import logo from './logo.svg';
import './App.css';

import Employee from './Employee';


function App() {
  return (
    <>
      <h1>React Forms and Event</h1>
     
      <Employee/>
     
    </>
    );
}

export default App;
